import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp2());
}

class MyWidget extends StatefulWidget {
  const MyWidget({super.key});

  @override
  State<MyWidget> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget>{
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(

      )
    );
  }
}