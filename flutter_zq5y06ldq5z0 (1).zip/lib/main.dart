import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}
class _MyAppState extends State<MyApp> {
  Widget build(BuildContext context) {
    var boxfit;
    var Boxfit;
    return MaterialApp(
    home: Scaffold(
      appBar: AppBar( 
        title:
        Row( 
          children:[
            Text("Adik",style:TextStyle(fontSize: 20,fontWeight:FontWeight.w900,color:Color.fromARGB(255, 255, 255, 255))),Spacer(),
            Row(
              children:[
                Icon(Icons.menu),
                Padding(padding:const EdgeInsets.only(left: 20.0)),
              ],
            )
          ],
        ),
      ),
       
        body:Container(
          decoration: const BoxDecoration (
            image: DecorationImage(
              image: NetworkImage("https://images.pexels.com/photos/2425232/pexels-photo-2425232.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
              ),
              fit:  BoxFit.cover,
            ),
          ),
      
          child:SingleChildScrollView(
          child:Column(
            children:[
              Image.network("https://images.pexels.com/photos/689784/pexels-photo-689784.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"),
              Row(
                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                 children: [SizedBox(height: 50),
                    Icon(Icons.favorite,color:Color.fromARGB(235, 241, 65, 65),),
                    Padding(padding:const EdgeInsets.symmetric(horizontal: 1.0)),
                    Icon(Icons.chat_bubble_outline,color:Color.fromARGB(255, 255, 255, 255),),
                    Padding(padding:const EdgeInsets.symmetric(horizontal: 1.0)),
                    Icon(Icons.share,color:Color.fromARGB(255, 255, 255, 255),), Spacer(),
                    Icon(Icons.bookmark_outline,color:Color.fromARGB(255, 255, 255, 255),),
                    Padding(padding:const EdgeInsets.symmetric(horizontal: 1.0)),
                 ], 
              ),
              Row(
                 children:[
                  Text("Penguien",style:TextStyle(fontSize: 20,fontWeight:FontWeight.w500,color:Color.fromARGB(255, 255, 255, 255))),
                ],
              ),
              SizedBox(height:25),
              Image.network("https://images.pexels.com/photos/25614397/pexels-photo-25614397/free-photo-of-close-up-of-lithops.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"),
              Row(
                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                 children: [SizedBox(height: 50),
                    Icon(Icons.favorite,color: Color.fromARGB(255, 255, 95, 83),),
                    Padding(padding:const EdgeInsets.symmetric(horizontal: 1.0)),
                    Icon(Icons.chat_bubble_outline,color:Color.fromARGB(255, 255, 255, 255)),
                    Padding(padding:const EdgeInsets.symmetric(horizontal: 1.0)),
                    Icon(Icons.share,color:Color.fromARGB(255, 255, 255, 255)), Spacer(),
                    Icon(Icons.bookmark_outline,color:Color.fromARGB(255, 255, 255, 255)),
                    Padding(padding:const EdgeInsets.symmetric(horizontal: 1.0)),
                 ], 
              ),
              Row(
                 children:[
                  Text("Pebbles",style:TextStyle(fontSize: 20,fontWeight:FontWeight.w500,color:Color.fromARGB(255, 255, 255, 255))),
                ],
              ),
            ],
          ),
        ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: (){},
          child:Icon(Icons.add),
        ),
      ),
    ); 
  }
}